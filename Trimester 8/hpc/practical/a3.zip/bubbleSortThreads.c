#include<stdio.h>
#include<omp.h>
#define MAX 1000000

void serial(int *arr, int n, double start1, double end1, int temp) {											
	start1 = omp_get_wtime();
	for(int i=0;i<n-1;i++) {
		for(int j=0;j<n-i-1;j++) {
			if(arr[j+1]<arr[j]) {
				temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
			}
		}
	}
    end1 = omp_get_wtime();
	// printf("\nsorted numbers through serial bubble sort are \n");
	// for(int j=0;j<n;j++) {
	// 	printf("%d\t",arr[j]);
	// }
	printf("\nTime Serial: \t %f \n\n", end1-start1); 

}
void parallel(int *arr, int n, double start, double end) {
	start = omp_get_wtime();

	// #pragma omp parallel for 
    for(int k=0;k<n+1/2;k++) {    
        #pragma omp parallel for 
			for(int j=0;j<n;j+=2) {
				int temp1;
				if(arr[j]>arr[j+1]) {
					temp1 = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp1;
				}        
			}
		
	    #pragma omp parallel for 
			for(int j=1;j<n-1;j+=2) {
				int temp2;
				if(arr[j]>arr[j+1]) {
					temp2 = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp2;
				}        
			}    
		 
	}        
    end = omp_get_wtime();
	printf("\nTime Parallel: \t %f \n\n", end-start); 

	// printf("sorted numbers through serial bubble sort are \n");
	// for(int i=0;i<n;i++) {
	// 	printf("%d\t",arr[i]);
	// }

}

void populate(int *arr, int n) {
	for(int i=0;i<n;i++) {
		arr[i]=MAX-i;
		// printf("%d\t",arr[i]);
	}    
	
}

int main() {
	int i, j, n, arr[MAX],arr1[MAX], temp, k;
	double start, end, start1, end1;         
	printf("enter no of elements ");
	scanf("%d",&n);
	
	populate(arr1, n);
	populate(arr, n);
	parallel(arr1, n, start, end);
	serial(arr, n, start1, end1, temp); 											

    // start = omp_get_wtime();
    // for(int k=0;k<(n+1)/2;k++) {    
    //     #pragma omp parallel for
	//     for(j=0;j<n-1;j+=2) {
    //         if(arr[j]>arr[j+1]) {
    //             temp1 = arr[j];
  	// 	        arr[j] = arr[j+1];
	// 	        arr[j+1] = temp1;
	//         }        
    //     }
	//     #pragma omp parallel for
    //     for(j=1;j<n-1;j+=2) {
    //         if(arr[j]>arr[j+1]) {
	//             temp2 = arr[j];
   	// 	        arr[j] = arr[j+1];
	// 	        arr[j+1] = temp2;
	//         }        
    //     }     
	// }        
    // end = omp_get_wtime();
	// // printf("sorted numbers through parallel execution are\n");
	// for(i=0;i<n;i++) {
	// 	printf("%d\t",arr[i]);
	// }
	// serial(arr, n);

    // start1 = omp_get_wtime();
	// for(i=0;i<n;i++) {
	// 	for(j=0;j<n-i-1;j++) {
	// 		if(arr[j+1]<arr[j]) {
	// 			int temp3;
	// 			temp3 = arr[j+1];
	// 			arr[j+1] = arr[j];
	// 			arr[j] = temp3;
	// 		}
	// 	}
	// }
    // end1 = omp_get_wtime();
	// printf("sorted numbers through serial bubble sort are \n");
	// for(i=0;i<n;i++) {
	// 	printf("%d\t",arr[i]);
	// }
	// printf("\n");
	// printf("\nTime Parallel: \t %f \n", end-start); 
	// printf("\nTime Serial: \t %f \n", end1-start1); 


}

